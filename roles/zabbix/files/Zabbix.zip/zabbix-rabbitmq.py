#!/usr/bin/python

import pika, sys, json

# Credentials for Zabbix Server
credentials = pika.PlainCredentials('mqadmin', 'mqadmin')

#RabbitMq Url
rabbitMqUrl = "10.30.11.23"
rabbitMqPort = 5672

# Set the connection parameters
parameters = pika.ConnectionParameters(rabbitMqUrl,
                                   rabbitMqPort,
                                   '/',
                                   credentials)
# Establish the connection
connection = pika.BlockingConnection(parameters)

# Get the Channel
channel = connection.channel()

# Getting the command line arguments from zabbix server
sendto = sys.argv[1]
subject = sys.argv[2]
message = sys.argv[3]

# Split the message to check the problem or recovery
messageArray = message.split(" | ");

# Queue Name
ZabbixQueveName = ""

# Routing Key
RoutingKey = ""

# Exchange Name
exchange = "zabbix-wolf"

# Zabbix problem routing key
ZabbixProblemRoutingkey = "zabbix-route-problem"

# Zabbix recovery routing key
ZabbixRecoveryRoutingkey = "zabbix-route-recovery"

# Message Json
messageQueve = {}

# Check if problem or recovery using length of messsage array
if messageArray[0] == "PROBLEM" :
    # Set the message body with recipient email address
     messageQueve = {
        "status" : messageArray[0],
        "sendTo" : sendto,
        "name" : messageArray[1],
        "hostname" : messageArray[2],
        "severity" : messageArray[3],
        "itemValue" : messageArray[4],
        "itemKey" : messageArray[5],
        "triggerId" : messageArray[6],
        "actionId" : messageArray[7],
        "eventDate" : messageArray[8],
        "eventTime" : messageArray[9],
        "description" : messageArray[10],
	"type" : "Trigger"
     }
     # Routing Key
     RoutingKey = ZabbixProblemRoutingkey
     # Queue Name
     ZabbixQueveName = "ZabbixProblem-wolf"
     # Declare the queue
     channel.queue_declare(queue=ZabbixQueveName,durable=True)
     # Bind the queue
     channel.queue_bind(exchange=exchange,
                        queue=ZabbixQueveName,
                        routing_key=ZabbixProblemRoutingkey)
else :
    # Set the message body with recipient email address
    messageQueve = {
       "status" : messageArray[0],
       "sendTo" : sendto,
       "name" : messageArray[1],
       "hostname" : messageArray[2],
       "severity" : messageArray[3],
       "itemValue" : messageArray[4],
       "itemKey" : messageArray[5],
       "triggerId" : messageArray[6],
       "actionId" : messageArray[7],
       "eventDate" : messageArray[8],
       "eventTime" : messageArray[9],
       "eventRecoveryValue" : messageArray[10],
       "eventRecoveryDate" : messageArray[11],
       "eventRecoveryTime" : messageArray[12],
       "description" : messageArray[13],
	"type" : "Trigger"
    }
    # Routing Key
    RoutingKey = ZabbixRecoveryRoutingkey
    # Queue Name
    ZabbixQueveName = "ZabbixRecovery-wolf"
    # Declare the queue
    channel.queue_declare(queue=ZabbixQueveName,durable=True)
    # Bind the queue
    channel.queue_bind(exchange=exchange,
                       queue=ZabbixQueveName,
                       routing_key=ZabbixRecoveryRoutingkey)

# Convert string to json
messageQueve = json.dumps(messageQueve)

# Publish the message
channel.basic_publish(exchange=exchange,
                      routing_key=RoutingKey,
                      body=messageQueve)
# Close the connection
connection.close()

