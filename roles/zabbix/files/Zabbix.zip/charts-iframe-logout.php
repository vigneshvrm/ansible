<?php
require_once dirname(__FILE__).'/include/config.inc.php';
require_once dirname(__FILE__).'/include/hostgroups.inc.php';
require_once dirname(__FILE__).'/include/hosts.inc.php';
require_once dirname(__FILE__).'/include/graphs.inc.php';

// VAR  TYPE    OPTIONAL        FLAGS   VALIDATION      EXCEPTION
$fields = [
    'userLogout' =>             [T_ZBX_STR, O_OPT, P_SYS, null,         null],
];

if(getRequest('userLogout')) {
   CWebUser::logout();
}
echo json_encode(array('result' => true));
?>
