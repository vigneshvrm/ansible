#!/bin/bash
JAVA_HOME=/opt/jdk1.8.0_221/
PATH=$JAVA_HOME/bin:$PATH
export PATH JAVA_HOME
export CLASSPATH=.
